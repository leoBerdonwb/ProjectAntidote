﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraController : MonoBehaviour
{
	[SerializeField]
	GameObject Inventory;

	GameObject actualObject;

	InputInteractions getInteractions;

	[SerializeField]
	Text Name, Actions;

	bool canPickUp, canPutInBag;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
		RaycastHit hit;

		if (Physics.Raycast(transform.position, transform.forward, out hit, 5))
		{
			actualObject = hit.collider.gameObject;
			getInteractions = actualObject.GetComponent<InputInteractions>();
		}
		else
		{
			ResetCamera();
		}

		if (actualObject != null)
		{
			Name.text = actualObject.name;

			if (getInteractions.toPickUp && !canPickUp)
			{
				Actions.text += "Press P to Pick Up\n";
				canPickUp = true;
			}

			if (getInteractions.toPutInTheBag & !canPutInBag)
			{
				Actions.text += "Press T to Take\n";
				canPutInBag = true;
			}
			Interactions();
		}
    }

	private void Interactions()
	{
		if (Input.GetKeyDown(KeyCode.T))
		{
			actualObject.transform.parent = Inventory.transform;
			actualObject.SetActive(false);
		}
		else if (Input.GetKeyDown(KeyCode.P))
		{

		}
	}

	private void ResetCamera()
	{
		actualObject = null;
		getInteractions = null;
		canPickUp = false;
		canPutInBag = false;
		Name.text = "";
		Actions.text = "";
	}
}
