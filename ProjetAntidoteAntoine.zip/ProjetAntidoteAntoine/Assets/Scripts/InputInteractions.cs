﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputInteractions : MonoBehaviour
{
	public bool toPickUp;

	public bool toPutInTheBag;
}
